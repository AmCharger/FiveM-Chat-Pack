# OOC Chat
## A very simple "out of character" chat script for FiveM roleplay servers.
### Displays OOC | Username in gray before users chat message..

![Screenshot](https://forum.fivem.net/uploads/default/original/2X/3/3c2961856fd5751cbf0b569a04c9ac83a7b87e91.jpg)

### Requirements
* [FiveM](https://fivem.net)

### Installation
1. Download the zip from [here](https://github.com/fuzzymannerz/ooc/archive/master.zip).
2. Unzip into the "_resources_" folder on your server and rename to "_ooc_".
3. Add `- ooc` to _citmp-server.yml_ in your server root.
4. Restart server

### How To Use
Use `/ooc message` in the in game chat.
