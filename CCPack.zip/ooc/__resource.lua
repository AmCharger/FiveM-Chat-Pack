description 'Enables use of /ooc for out of character chat.'
server_script 'server.lua'