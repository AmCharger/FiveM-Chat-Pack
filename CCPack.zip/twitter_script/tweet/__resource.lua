description 'Enables use of /tweet for in character chat.'
server_script 'server.lua'